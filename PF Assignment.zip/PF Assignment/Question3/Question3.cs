﻿using System;

namespace ConsoleApplication3
{
    class Question3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("class ID: 121183");
            Console.WriteLine("StudentID: 66503");
            Console.WriteLine("Name: Zain Ahmed");
            Console.WriteLine("Submssin Date: 28th oct 2026");
            int year;

            //We have to enter the year (Digits)
            Console.WriteLine("Enter Year");
            year = Convert.ToInt32(Console.ReadLine());


            //We have to check if the year is a leap year or not
            if (year % 400 == 0)
            {
                Console.WriteLine("leap year");
            }
            else if (year % 100 == 0)
            {
                Console.WriteLine("not a leap year");
            }
            else if (year % 4 == 0)
            {
                Console.WriteLine("leap year");
            }
            else
            {
                Console.WriteLine("not a leap year");
            }
        }
    }
}